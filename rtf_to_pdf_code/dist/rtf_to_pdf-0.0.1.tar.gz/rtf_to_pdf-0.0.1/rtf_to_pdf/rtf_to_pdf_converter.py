from rtf_to_pdf.config.configuration import Configuration
from rtf_to_pdf.operations.marker_remover import MarkerRemover
from rtf_to_pdf.operations.str_remover import StrRemover
from rtf_to_pdf.utilities.common_fun import CommonFun
from rtf_to_pdf.operations.rtf_to_pdf_m import RtfToPdfM
import os

__all__ = ['RtfToPdf']


class RtfToPdf(object):

    def __init__(self, bucket_nm: str, prop_file_nm: str):
        self.prop = Configuration(bucket_nm, prop_file_nm)
        self.prop.config()
        self.rtf_to_pdf_m = RtfToPdfM(self.prop)
        self.m_remover = MarkerRemover(self.prop)
        self.str_remover = StrRemover(self.prop)
        self.common_fun = CommonFun(self.prop)

    def rtf_to_pdf(self):
        print("""**********************""")
        print(self.common_fun.get_file_list(self.prop.src_bucket, self.prop.src_prefix))
        for key in self.common_fun.get_file_list(self.prop.src_bucket, self.prop.src_prefix):
            rtf_file_name = os.path.basename(key)
            print("************************ rtf_file_name***************")
            dir_loc = os.path.dirname(os.path.abspath(key))
            if rtf_file_name:
                pdf_file_name = rtf_file_name.replace('rtf', 'pdf')

                print("**************** rtf file name ********************")
                print(pdf_file_name)
                # Download RTF from S3
                downloaded_rft_path = self.common_fun.download_file_from_s3(self.prop.src_bucket, key)

                # Convert RTF to PDF
                buffer_content = self.rtf_to_pdf_m.rtf_to_pdf_m(downloaded_rft_path)

                self.common_fun.upload_file_to_s3(buffer_content, self.prop.dist_bucket,
                                                  self.prop.dist_prefix + pdf_file_name)
                # self.doc_to_pdf.doc_to_pdf(self.prop.doc_file, self.prop.pdf_file)
                # self.m_remover.marker_remover(self.prop.pdf_file, self.prop.new_pdf_file)
                # self.str_remover.str_remover(self.prop.new_pdf_file, self.prop.final_pdf)
