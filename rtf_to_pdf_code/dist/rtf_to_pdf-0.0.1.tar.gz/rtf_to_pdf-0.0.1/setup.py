from setuptools import setup, find_packages
import os

# here = os.path.abspath(os.path.dirname(__file__))

VERSION = '0.0.1'
DESCRIPTION = 'Converting RTF to PDF'
# LONG_DESCRIPTION = 'A package that allows to build simple streams of video, audio and camera data.'

# Setting up
setup(
    name="rft_to_pdf",
    version=VERSION,
    author="Akhil (Akhilesh Chand)",
    author_email="<akhilesh.chand@carelon.com>",
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    # long_description=long_description,
    packages=find_packages(),
    # packages=find_packages(include=['caa_rxdc', 'caa_rxdc.*','caa_rxdc.*.*']),
    # packages=find_packages(','), , 'pypiwin32'
    # install_requires=['botocore', 'boto3', 'pywin32', 'fitz', 'pywin32', 'PyPDF2'],
    # dependency_links=[
    #     os.path.join(os.getcwd(), '', 'Spire.Doc-12.3.2-py3-none-win_amd641.whl')
    # ],

    # keywords=['python', 'video', 'stream', 'video stream', 'camera stream', 'sockets'],
    classifiers=[
        "Development Status :: 1 - Planning",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)
