from rtf_to_pdf.config.configuration import Configuration

__all__ = [Configuration]
