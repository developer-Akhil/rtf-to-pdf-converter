import fitz

__all__ = ['StrRemover']


class StrRemover:

    def __init__(self, prop):
        self.prop = prop

    def str_remover(self, new_pdf_file: str, final_pdf: str):
        doc = fitz.open(new_pdf_file)
        page = doc.load_page(0)
        draft = page.search_for(self.prop.pdf_str)

        for rect in draft:
            annot = page.add_redact_annot(rect)
            page.apply_redactions()
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)
            # then save the doc to a new PDF:
        doc.save(final_pdf, garbage=3, deflate=True)
